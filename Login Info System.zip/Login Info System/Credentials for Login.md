Database Name: db_admin
Database File: db_admin.sql
 
Admin Info
 Admin Username: admin@gmail.com
 Admin pass: admin123</li>

User Info
 Username: trixiebalidiong@gmail.com
 Password: trixie123





